NIRCam:

FTrans_f070w.dat
FTrans_f090w.dat
FTrans_f115w.dat
FTrans_f150w.dat
FTrans_f200w.dat
FTrans_f277w.dat
FTrans_f356w.dat
FTrans_f444w.dat

MIRI filters: 

FTrans_f560w.dat
FTrans_f770w.dat
FTrans_f1000w.dat
FTrans_f1130w.dat
FTrans_f1280w.dat
FTrans_f1500w.dat
FTrans_f1800w.dat
FTrans_f2100w.dat
FTrans_f2550Aw.dat

